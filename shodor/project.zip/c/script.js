var canvas, ctx, time = 1, wWidth, wHeight, fish = [], seals = [], waves = [], algae = [], input1, input2, input3, timeInput, fishimage;
window.onload = function init() {
	canvas = document.getElementById("fishsealcanvas");
	ctx = canvas.getContext("2d");
	wWidth = window.innerWidth;
	wHeight = window.innerHeight;
	canvas.width = wWidth;
	canvas.height = wHeight;
	input1 = document.getElementById("fishcount");
	input2 = document.getElementById("sealcount");
	input3 = document.getElementById("slider");
	timeinput = document.getElementById("timeslider");
	fishimage = new Image();
	fishimage.src = "http://www.shodor.org/~tylerf/fish.png";
	configure();
	createWater();
	createAlgae();
	createFish();
	render();
	update();
}
function configure() {
	time = Math.round((timeinput.value*timeinput.value)/500);
}
function render() {
	setInterval(function(){
		ctx.clearRect(0, 0, canvas.width, canvas.height);
		drawWater();
		drawAlgae();
		drawFish();
	}, 1000/60);
}
function update() {
	changeWater();
	changeAlgae();
	updateFish();
	if (1 != 0 ) {
		setTimeout(update, time);
	}
}


//Fish
function createFish() {
	for (i=0; i<200; i++) {
		fish[fish.length] = new Fish();
		console.log(fish[i].cx);
	}
}
function updateFish() {
	for (i=0; i<fish.length; i++) {
		var pes = fish[i];
		pes.x += pes.cx;
		pes.y += pes.cy;
	}
}
function drawFish() {
	for (i=0; i<fish.length; i++) {
		var pes = fish[i];
		ctx.rotate(pes.angle+1.6);
		ctx.drawImage(fishimage, pes.x, pes.y, 10, 20);
		ctx.rotate(-(pes.angle+1.6));
	}
}



//objects
function Fish() {
	this.x = Math.round(Math.random()*canvas.width);
	this.y = Math.round(Math.random()*canvas.height);
	this.size = 10 + Math.round(Math.random()*10);
	this.angle = Math.random()*2*Math.PI;
	this.cx = Math.cos(this.angle);
	this.cy = Math.sin(this.angle);
	this.tagged;
	this.health = 100;
	this.food = 100;
	//this.update = function() {}
}